var is=false,isz2=false,isz3=false,isz1=false,a,b,c,isj=false;//20521209
function useItem()
{
is=true;
}
function leaveGame()
{
is=false;
}
function modTick()
{
if(is==true)
{
var x=getPlayerX(),y=getPlayerY()-2,z=getPlayerZ();
    if(getTile(x,y-1,z)==49&&isz3==true)
{
if(getTile(x+1,y,z)==49||getTile(x-1,y,z)==49||getTile(x,y,z+1)==49||getTile(x,y,z-1)==49)
{
if(getTile(x,y+3,z)==49)
{
if(getTile(x+1,y+2,z)==49||getTile(x-1,y+2,z)==49||getTile(x,y+2,z+1)==49||getTile(x,y+2,z-1)==49)
{
if(isj==false)
{
a=x;b=y;c=z;
setPosition(getPlayerEnt(),205,23,209);

isj=true;
}
else if(isj==true)
{
setPosition(getPlayerEnt(),a+3,b,c);
isj=false;
}
}
}
}

}
else if(isz1==false)
{
for(var xy1=200;xy1<220;xy1++)
{
for(var xy2=200;xy2<220;xy2++)
{
setTile(xy1,20,xy2,87);
for(var h=1;h<10;h++)
{
setTile(xy1,20+h,xy2,0);
}
}
}
for(var xy3=200;xy3<220;xy3++)
{
for(var xy4=200;xy4<220;xy4++)
{
setTile(xy3,30,xy4,87);
}
}
isz1=true;
}
else if(isz2==false)
{
for(var xy1=200;xy1<220;xy1++)
{
for(var xy2=0;xy2<13;xy2++)
{
setTile(xy1,19+xy2,220,87);
setTile(xy1,19+xy2,199,87);
setTile(199,19+xy2,xy1,87);
setTile(220,19+xy2,xy1,87);
}
}
isz2=true;
}
else if(isz3==false)
{
setTile(203,21,210,49);
setTile(203,22,210,49);
setTile(203,23,210,49);
setTile(203,24,210,49);
setTile(203,25,210,49);
setTile(203,21,207,49);
setTile(203,22,207,49);
setTile(203,23,207,49);
setTile(203,24,207,49);
setTile(203,25,207,49);
setTile(203,21,209,49);
setTile(203,21,208,49);
setTile(203,25,209,49);
setTile(203,25,208,49);
setTile(204,21,210,89);
setTile(204,21,207,89);

setTile(200,29,200,10);
setTile(200,29,219,10);
setTile(219,29,219,10);
setTile(219,29,200,10);
setTile(210,21,210,10);
setTile(213,21,210,10);
setTile(213,21,207,10);
setTile(210,21,207,10);

setTile(205,21,207,51);
setTile(206,21,207,51);
setTile(205,21,210,51);
setTile(206,21,210,51);


setTile(209,21,211,87);
setTile(209,21,210,87);
setTile(209,21,209,87);
setTile(209,21,208,87);
setTile(209,21,207,87);
setTile(209,21,206,87);
setTile(210,21,211,87);
setTile(211,21,211,87);
setTile(212,21,211,87);
setTile(213,21,211,87);
setTile(214,21,211,87);
setTile(210,21,206,87);
setTile(211,21,206,87);
setTile(212,21,206,87);
setTile(213,21,206,87);
setTile(214,21,206,87);
setTile(214,21,211,87);
setTile(214,21,210,87);
setTile(214,21,209,87);
setTile(214,21,208,87);
setTile(214,21,207,87);
setTile(214,21,206,87);
print("地狱制造成功，作者:qsefthukol");
isz3=true;

}
}
}